<?php
	 function sominx_get_all_menus(){
     $menus = get_terms( 'nav_menu', array( 'hide_empty' => true ) ); 
     $results = array();
     foreach ($menus as $key => $menu) {
      $results[$menu->slug] = $menu->name;
     }
     return $results;
  }
  	Redux::setSection( $opt_name, array(
	 	'title' 	=> esc_html__('Header Options', 'sominx'),
	 	'icon' 	=> 'el-icon-compass',
	 	'fields' => array(
			array(
			  'id' 		=> 'header_logo', 
			  'type' 	=> 'media',
			  'url' 		=> true,
			  'title' 	=> esc_html__('Logo in header default', 'sominx'), 
			  'default' => ''
			),  
			array(
			  'id'  		=> 'header_mobile_settings',
			  'type'  	=> 'info',
			  'raw' 		=> '<h3 class="margin-bottom-0">' . esc_html__('Header Mobile settings', 'sominx') . '</h3>'
			),
			array(
			  'id' 		=> 'hm_logo',
			  'type' 	=> 'media',
			  'url' 		=> true,
			  'title' 	=> esc_html__('Header Mobile | Logo', 'sominx'),
			  'default' => ''
			),
			array(
			  'id' 		=> 'hm_show_topbar',
			  'type' 	=> 'button_set',
			  'title' 	=> esc_html__('Show Topbar', 'sominx'),
			  'options' => array('yes' => 'Enable', 'no' => 'Disable'),
			  'default' => 'yes'
			),
			array(
	        'id' 		=> 'hm_topbar_information',
	        'type' 	=> 'editor',
	        'title' 	=> esc_html__('Topbar Information', 'sominx'),
	        'default' => '<ul class="inline"><li><i class="fa fa-envelope"></i>contact@example.com</li><li><i class="fa fa-phone"></i>666 888 0000</li></ul>'
	      ),
			
			//-- Socials --
			array(
			  'id'  		=> 'header_mobile_socials_settings',
			  'type'  	=> 'info',
			  'raw' 		=> '<h3 class="margin-bottom-0">' . esc_html__('Social Header Mobile Settings', 'sominx') . '</h3>'
			),
			array(
				'id'			=> 'hm_social_facebook',
				'type' 		=> 'text',
				'title' 		=> esc_html__('Facebook', 'sominx'),
				'desc'		=> esc_html__('Enter your Facebook profile URL.', 'sominx'),
				'default'	=> ''
			),
			array(
				'id'			=> 'hm_social_instagram',
				'type'		=> 'text',
				'title'		=> esc_html__('Instagram', 'sominx'),
				'desc'		=> esc_html__('Enter your Instagram profile URL.', 'sominx'),
				'default'	=> ''
			),
			array(
				'id'			=> 'hm_social_twitter',
				'type'		=> 'text',
				'title'		=> esc_html__('Twitter', 'sominx'),
				'desc'		=> esc_html__('Enter your Twitter profile URL.', 'sominx'),
				'default'	=> ''
			),
			array(
				'id'			=> 'hm_social_linkedin',
				'type'		=> 'text',
				'title'		=> esc_html__('LinedIn', 'sominx'),
				'desc'		=> esc_html__('Enter your LinkedIn profile URL.', 'sominx'),
				'default'	=> ''
			),
			array(
				'id'			=> 'hm_social_pinterest',
				'type'		=> 'text',
				'title'		=> esc_html__('Pinterest', 'sominx'),
				'desc'		=> esc_html__('Enter your Pinterest profile URL.', 'sominx'),
				'default'	=> ''
			),
			array(
				'id'			=> 'hm_social_tumblr',
				'type'		=> 'text',
				'title'		=> esc_html__('Tumblr', 'sominx'),
				'desc'		=> esc_html__('Enter your Tumblr profile URL.', 'sominx'),
				'default'	=> ''
			),
			array(
				'id'			=> 'hm_social_vimeo',
				'type'		=> 'text',
				'title'		=> esc_html__('Vimeo', 'sominx'),
				'desc'		=> esc_html__('Enter your Vimeo profile URL.', 'sominx'),
				'default'	=> ''
			),
			array(
				'id'			=> 'hm_social_youtube',
				'type'		=> 'text',
				'title'		=> esc_html__('YouTube', 'sominx'),
				'desc'		=> esc_html__('Enter your YouTube profile URL.', 'sominx'),
				'default'	=> ''
			)
	 	)
  	));